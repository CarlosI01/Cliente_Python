from zeep import client

cliente = client('http://localhost:8080/ProyectoWedService_V1/Service?WSDL');

 if cliente.login("CarlosTH", "12345")
            print("Credenciales Correctas")
 else :
            println("Incorrecto")
    
    
